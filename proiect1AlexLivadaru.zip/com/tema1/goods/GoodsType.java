package com.tema1.goods;

public enum GoodsType { Legal, Illegal }
